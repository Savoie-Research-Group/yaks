import sys,os,argparse,fnmatch,subprocess,time,shutil
import numpy as np
import cantera as ct
import matplotlib.pyplot as plt
import pickle
from write_yaml import smiles_to_inchi
from write_yaml import write_yaml_file
from rdkit import Chem
from rdkit.Chem import Descriptors

# all functions in taffi
sys.path.append('../utilities')
from taffi_functions import *
from utility import return_smi,return_inchikey,parse_smiles

# Author: Michael Woulfe
""" Along with yaks_config.txt (same config file you use for write_yaml.py), runs cantera microkinetic modeling simulation and prints results for future exploration

Notes to self:  copy a yarp config file
                keep it generic and then add different variables for each individual species (if radicals/cations/anions)
                    add a section for cantera simulations

                track useful variables throughout YARP exploration

                submit YARP jobs to cluster, run yaks on sinteractive claimed node
                    - define run_simulation function
                    - define analyze results function?!?
                    - limit print statements

                lists: species to explore, already explored species,
                write all files into a newly created folder (ex: khp_yaks_3_3 [rounds, species])

                difficulties/new ideas: 
                    water catalyzed section (work after normal section works)
                    restart steps: which part of what step?
                    following bad channels/verification schemes.
                    cleaning scheme to delete unnecessary YARP files


        general overview:
            yaks .py (monitor jobs and wait until done for all steps)
                - run yarp on input molecule [written output- YARP folders]
                    - name output_folder _whatever_0_1 (round 0, species 1)
                - write_yaml.py [written output - yaml file]
                - run_kinetic_modeling
                - analyze results [ written output- csv files of , plots?, prioritization]
                Round 2
                - run yarp on top n results (start with 3)
                - 
"""
def main(argv):

    parser = argparse.ArgumentParser(description='Driver script for submitting YARP jobs with Gaussian engine.')

    #optional arguments                                             
    parser.add_argument('-c', dest='config', default='yaks_config.txt',
                        help = 'The program expects a configuration file from which to assign various run conditions. (default: yaml_config.txt in the current working directory).  Conveniently, write_yaml.py and analyze_cantera.py run off same yaml file.')
    
    print("parsing configuration directory...")
    args=parser.parse_args()
    config_path =args.config
    c = parse_configuration(parser.parse_args())
    run_yaks(c, config_path)

    return


def run_yaks(c,config_path):
    cwd = os.getcwd()
    yaks_path = f"{cwd}/{config_path}"
    # # load in reactant dictionaries
    # reactant_dict = c["reactant_dict"]
    # print(reactant_dict)
    # smi2inchi = c["smi2inchi"]
    # print("Loading Smile to Inchi Dict...")
    # if os.path.isfile(smi2inchi):
    #     with open(smi2inchi,'rb') as f: 
    #         smi_inchi_dict = pickle.load(f)
    # else: smi_inchi_dict = {}
    # # make folder to store configs/output files and YARP outputs
    # if os.path.isdir(c["calc_folder"]) is False: os.mkdir(c["calc_folder"])
    # if os.path.isdir(c["output_path"]) is False: os.mkdir(c["output_path"])

    
    # node_tracker = {}
    previous_nodes = []
    # only one initial species for now
    if len(c["mol_fraction"].split(','))==1: ini_smiles = c["mol_fraction"].split(':')[0]
    if len(previous_nodes)== 0:
        new_nodes = [ini_smiles]
    # smi_inchi_dict, inchi_list = smiles_to_inchi(new_nodes, smi_inchi_dict) # create lists of inchis/ update smi_inchi_dict
    # # print(new_nodes, inchi_list)
    # # test to see if it's the same

    exp_steps = 2
    # # loop start
    for depth in range(exp_steps): # need to add to config
    #     print("depth", depth)
        if depth == 1: break # break for iterative growth
    #     # Reaction Enumeration
    #     print("Running ERS_enumeration...")
    #     inchi_list = run_ERS(c, new_nodes, depth)
    #     # record inchis in node tracker
    #     for num, inchi in enumerate(inchi_list):
    #         print(num, inchi)
    #         # node tracker[k] = [inchi, smile]
    #         node_tracker[f"{depth}_{num}"] = [inchi, new_nodes[num]]
    #     print(node_tracker)

    #     print("Running YARP exploration...")
    #     run_yarp_exp(c, node_tracker,depth, yaks_path)

    #     # # write yaml file
    #     print("Writing .yaml file...")
        file_name = c['calc_folder'].split('/')[-1]
        # write_yaml_file(c, c['output_path'], folder2 = 'NA', file_name = c['calc_folder'].split('/')[-1])
    #     # add depth to write_yaml's typical output
        if os.path.exists(f"{c['output_path']}/{file_name}.yaml"):
            os.rename(f"{c['output_path']}/{file_name}.yaml", f"{c['output_path']}/{file_name}_{depth}.yaml")
        if os.path.exists(f"{c['output_path']}/{file_name}_{depth}.yaml"):
            print(f"{file_name}_{depth}.yaml succesfully created")
        else: 
            print(f"Error: {file_name}_{depth}.yaml was not created")
            return
        # # run kinetic simulation
        previous_nodes += new_nodes # add explored nodes to list of previous explorations
        previous_nodes, new_nodes, possible_bimole = run_kinetics(yaml_path=f"{c['output_path']}", yaml_name=f"{file_name}_{depth}.yaml",time_step = float(c['time_step']), steps = float(c['steps']), rule = c['rule'],\
                                                 reactor = c['reactor'], previous_nodes=previous_nodes, num_nodes = int(c['num_nodes']), cnf_thresh= float(c['cnf_thresh']))
        print(previous_nodes, new_nodes, possible_bimole)
    
    rule = "cnf" # cnf, cum_conc, final_conc
    steps = 6000
    time_step = 0.1
    yaml_path = "/scratch/bell/mwoulfe/yaks/yamls"
    yaml_name = "test_0"

    
    reactor = "IGCPR"
    
    num_nodes = 3

        

  
###########################################
####              FUNCTIONS            ####
###########################################
def run_yarp_exp(c, node_tracker, depth, yaks_path):
    work_dir = c['calc_folder']
    # write yarp submission files
    for k, v in node_tracker.items():
        if fnmatch.fnmatch(k, f"{depth}_*"):
            # make working directory folders
            if os.path.isdir(f"{work_dir}/yarp_{k}") is False: os.mkdir(f"{work_dir}/yarp_{k}")
            # write input_list_{depth}_{node}
            print(f"{work_dir}/yarp_{k}/input_list_{k}.txt")
            with open(f"{work_dir}/yarp_{k}/input_list_{k}.txt",'w') as g:
                if isinstance(v[0], str):
                    for i in v[0]:                                                                 
                        g.write(f"{i}")
            # write config_{depth}_{species}.txt
            # c, path to template, output path, smiles, k, v
            write_yarp_config(c,c['config_template'], yaks_path, f"{work_dir}/yarp_{k}/{k}_config.txt", f"{c['output_path']}/{k}", k, v) 
            # write yarp_submit
            write_yarp_submit(c, f"{work_dir}/{k}.submit", f"{work_dir}/yarp_{k}/{k}_config.txt", f"{c['output_path']}/{k}", k, v)

            # copy YARP to working directories (so we can have mulitple iterations running at once)
            if os.path.isdir(f"{work_dir}/yarp_{k}") is False: os.mkdir(f"{work_dir}/yarp_{k}")
            # copy utilities folder to working dir (keeps from having to edit those files specifically for yaks)
            if os.path.isdir(f"{work_dir}/utilities") is False:
                shutil.copytree(f"{'/'.join(work_dir.split('/')[:-1])}/yaks/utilities",f"{work_dir}/utilities")
            # copy critical scripts into the correct calc directory
            shutil.copy(f"{'/'.join(work_dir.split('/')[:-1])}/yaks/locate_TS.py", f"{work_dir}/yarp_{k}/locate_TS.py")
            shutil.copy(f"{'/'.join(work_dir.split('/')[:-1])}/yaks/analyze_crest_output.py", f"{work_dir}/yarp_{k}/analyze_crest_output.py")
            shutil.copy(f"{'/'.join(work_dir.split('/')[:-1])}/yaks/refine.py", f"{work_dir}/yarp_{k}/refine.py")
            # make directories necessary to run yarp
            if os.path.isdir(f'{c["calc_folder"]}/yarp_{k}/xyz_files') is False: os.mkdir(f'{c["calc_folder"]}/yarp_{k}/xyz_files')
            if os.path.isdir(f'{c["calc_folder"]}/yarp_{k}/DFT') is False: os.mkdir(f'{c["calc_folder"]}/yarp_{k}/DFT')
    # submit yarp jobs to cluster 
    all_yarp_jobs = []
    for file in os.listdir(work_dir):
        if fnmatch.fnmatch(file, f"{depth}_*.submit"):
            # print(file, "yes")
            command = f"sbatch {work_dir}/{file}" # submit yarp jobs
            output = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).communicate()[0].decode('utf-8')
            print(output)
            for i in output.split(): all_yarp_jobs.append(i)
            # all_yarp_jobs.append(output.split())
    monitor_jobs(all_yarp_jobs)


def write_yarp_submit(c, submit_file, config_file, yarp_output_file, k, v):
    sched = c['sched']
    work_dir = c['calc_folder']
    if sched == "slurm":    
        with open(f"{submit_file}",'w') as f:                                                                 
            f.write("#!/bin/bash\n")
            f.write("#\n")
            f.write(f"#SBATCH --job-name=yarp_{submit_file.split('/')[-1]}\n")
            f.write(f"#SBATCH --output={'.'.join(submit_file.split('.')[:-1])}.out\n")
            f.write(f"#SBATCH --error={'.'.join(submit_file.split('.')[:-1])}.err\n")
            f.write(f"#SBATCH -A bsavoie\n")
            f.write("#SBATCH --nodes=1\n")
            f.write("#SBATCH --cpus-per-task=4\n") # more nodes for memory requirement
            f.write("#SBATCH --mem-per-cpu=1G\n")         # for large reaction dictionaries (glucose network with 500+ explorations)
            f.write(f"#SBATCH --time 12:00:00\n") # ten days 


            # print out information
            f.write("\n# cd into the submission directory\n")
            f.write(f"cd {work_dir}/yarp_{k}\n")
            f.write(f"echo Working directory is ${work_dir}/yarp_{k}\n")
            f.write("echo Running on host `hostname`\n")
            f.write("echo Start Time is `date`\n")
            f.write('export PATH="/depot/bsavoie/apps/anaconda3/bin/:$PATH"\n')
            f.write("source activate python3\n")


            # python locate_TS.py
            f.write(f"python {work_dir}/yarp_{k}/locate_TS.py -c {config_file} -o {yarp_output_file}\n")
            f.write("\nwait\n")
            f.write("echo End Time is 'date'\n")


def write_yarp_config(c, config_template_path, yaks_config_path, output_path, output_folder, k, v):

    modified_lines = []
    # Read content from the input file
    with open(config_template_path, 'r') as f, open(yaks_config_path, 'r') as g:
        # parse yaks config.txt
        config_dict = {}
        for line in g:
            desired_line = line.split('#')[0].strip()
            if len(desired_line.split()) ==2:
                config_dict[desired_line.split()[0]] = desired_line.split()[1]
        # parse config_template.txt and splice yaks_config.txt responses into it
        for line in f:
            modified_line = line.split('#')[0].strip()
            if len(modified_line.split()) ==2:
                temp = modified_line.split()

                # for molecule specific requests, use rdkit to parse charge and unpaired electrons
                if temp[0] == "charge": 
                    mol = Chem.MolFromSmiles(v[1])
                    if mol:
                        formal_charge = Chem.GetFormalCharge(mol)
                        temp[1] = str(formal_charge)
                elif temp[0] == "unpair":
                    mol = Chem.MolFromSmiles(v[1])
                    if mol:
                        num_unpaired_electrons = Descriptors.NumRadicalElectrons(mol)
                        temp[1] = str(num_unpaired_electrons)
                # specific to output locations/which iteration
                elif temp[0] == "input_react":
                    temp[1] = str(f"input_list_{k}.txt")
                elif temp[0] == "output_path":
                    temp[1] = str(output_folder)
                else:
                    # else, replace values with yaks_config.txt values
                    try:
                        temp[1]= str(config_dict[temp[0]])
                    except KeyError:
                        pass
                # print(temp, type(temp[1]))
                modified_line =  f"{temp[0]:<20}\t{temp[1]}"
                
                modified_lines.append(modified_line)
                

    with open(output_path, 'w') as of:
        for modified_line in modified_lines:
            of.write(f"{modified_line}\n")


def run_ERS(c, new_nodes, depth): # depth is integer of exploration depth
    
    # get working folder direactory 
    work_dir = c['calc_folder']

    sched = c['sched']
    ers_queue = c['ers_queue']
    Wt = int(c['ers_walltime'])
    reactant_dict = c['reactant_dict']
    if Wt >= 1: min_flag = 0
    elif Wt < 1 and Wt > 0: 
        min_flag = 1
        Wt = Wt*60
    if sched == "slurm":    
        with open(f"{work_dir}/ERS_{depth}.submit",'w') as f:                                                                 
            f.write("#!/bin/bash\n")
            f.write("#\n")
            f.write(f"#SBATCH --job-name=ERS_{depth}\n")
            f.write(f"#SBATCH --output={work_dir}/ERS_{depth}.out\n")
            f.write(f"#SBATCH --error={work_dir}/ERS_{depth}.err\n")
            f.write(f"#SBATCH -A {ers_queue}\n")
            f.write("#SBATCH --nodes=1\n")
            f.write("#SBATCH --mem-per-cpu=1G\n")
            
            # assign wall-time
            if min_flag == 0:
                f.write(f"#SBATCH --time {Wt}:00:00\n")
            elif min_flag == 1:
                f.write(f"#SBATCH --time 00:{Wt}:00\n")

            # print out information
            f.write("\n# cd into the submission directory\n")
            f.write(f"cd {work_dir}\n")
            f.write(f"echo Working directory is ${work_dir}\n")
            f.write("echo Running on host `hostname`\n")
            f.write("echo Start Time is `date`\n")
            f.write('export PATH="/depot/bsavoie/apps/anaconda3/bin/:$PATH"\n')
            f.write("source activate python3\n")
            # f.write("conda info --envs\n")

            # f.write("source activate python3\n")

            # run ERS_enumeration
            f.write(f"python {'/'.join(os.getcwd().split('/')[:-1])}/ERS_enumeration/reaction_enumeration.py inp_smiles.txt -rd {reactant_dict} -ff mmff94 -P 1 -t [3]\n")
            f.write("\nwait\n")
            f.write("echo End Time is 'date'\n")

    # write new node smiles into inp_smiles.txt
    with open(f'{work_dir}/inp_smiles.txt','w') as g:
        if isinstance(new_nodes, list):
            for i in new_nodes:                                                                 
                g.write(f"{i}\n")
        if isinstance(new_nodes, str):
            for i in new_nodes:                                                                 
                g.write(f"{i}")

    command = f"sbatch {work_dir}/ERS_{depth}.submit"
    output = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).communicate()[0].decode('utf-8')
    monitor_jobs(output.split())
    inchi_list = []
    with open(f"{work_dir}/ERS_{depth}.out", 'r') as file:
        for line in file:
            if "Inchi index is" in line:
                inchi_list.append(line.split()[-1])
    return inchi_list

# function to run kinetic simulation, returns list of previous nodes and, new nodes to explore
def run_kinetics(yaml_path, yaml_name, time_step, steps, rule, reactor, previous_nodes, num_nodes, cnf_thresh):

    yaml = f"{yaml_path}/{yaml_name}"
    gas = ct.Solution(yaml) # make a reactor variable in yaks_config.txt
    if reactor == "IGCPR": r = ct.IdealGasConstPressureReactor(contents=gas, energy='off', name='isothermal_reactor')
    sim = ct.ReactorNet([r])
    states = ct.SolutionArray(gas, extra=['t'])

    # gives snapshot of system
    print(gas(), f"T0: {gas.T}", f"Species: {len(gas.Y)}", f"Reactions: {len(states.reactions())}")

    species = states.species_names
    rxn_list = states.reactions()

    # Simulation 
    sim.verbose = True
    t_end = steps * time_step
    
    print("sim start")
    # sim loop
    states.append(r.thermo.state, t=sim.time)
    while sim.time <= t_end:
        sim.advance(sim.time + time_step)
        states.append(r.thermo.state, t=sim.time)
    print("sim end")

    if rule == 'cnf':
        if fnmatch.fnmatch(yaml, "*_0.yaml") or fnmatch.fnmatch(yaml, "*_pre*"): # ignore first time step if model is beyond first stages of yaml
            spe_net = np.trapz(states.net_production_rates[:], dx=time_step, axis=0)
        else: spe_net = np.trapz(states.net_production_rates[1:], dx=time_step, axis=0)    
        net_states = zip(spe_net,species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]

    elif rule == 'final_conc':
        net_states = zip(states.X[-1,:],species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]
    
    elif rule == 'final_mass':
        net_states = zip(states.Y[-1,:],species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]

    elif rule == 'cum_conc':
        conc_net = np.trapz(states.x[:], dx=time_step, axis=0)
        net_states = zip(conc_net,species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]

    # extra analysis
    spe_cre = np.trapz(states.creation_rates, dx=time_step, axis=0)
    spe_des = np.trapz(states.destruction_rates, dx=time_step, axis=0)
    rxn_net = np.trapz(states.net_rates_of_progress, dx=time_step, axis=0)

    # write rates to excel spreadsheet, save in analysis folder
    # make concentration/mass/net creation plots and save them to analysis folder (one folder for each step)
    possible_bimole = []
    new_nodes = [] 
    high_value = net_states[0][0]
    for i in net_states:
        # if we are using cnf and there is a large gap between the highest value and another one in the top 5,
        # skip low cnf values (save computational cost/avoid exploring down unfavorable pathways)
        # if rule == 'cnf':
        #     if float(high_value)/float(i[0])<= 10**cnf_thresh:
        #         return previous_nodes, new_nodes, possible_bimole
        if i[1] in previous_nodes: 
            possible_bimole.append(i[1])
        elif i[1] not in previous_nodes:
            new_nodes.append(i[1])
            previous_nodes.append(i[1])
        if len(new_nodes) == num_nodes:
            print(previous_nodes, new_nodes)
            # return once we find correct number of nodes
            return previous_nodes, new_nodes, possible_bimole
    # return if case we never reach correct number of nodes
    return previous_nodes, new_nodes, possible_bimole


# Function for keeping tabs on the validity of the user supplied inputs
# Function for keeping tabs on the validity of the user supplied inputs
def parse_configuration(args):
    
    # Convert inputs to the proper data type
    if os.path.isfile(args.config) is False:
        print("ERROR in python_driver: the configuration file {} does not exist.".format(args.config))
        quit()
    
    # Process configuration file for keywords
    keywords = ["input_type","reactant_dict","smi2inchi","output_path","pygsm_path","e_dict","ff","apply_tcit","tcit_result","hf_cut","charge","unpair","batch","sched","restart_step","eps",\
                "select_conf","low-irc","dft-irc","criterion","memory","irc-image","stepsize","irc-model","dg_thresh","compute_product","level","nimage","add-tor","conv-tor","relax_end","low_wt","low_njobs","low_queue","low_procs",\
                "c_method","c_wt","c_njobs","c_nprocs","n_max","c_queue","add-joint","c_path","functional","basis","dispersion","solvation","high_wt","ppn","high_procs","high_njobs","high_queue","parallel",\
                "rads","rev_rxns","energy_units","eos","kinetics","reactions","transport","temp","pres","pres_units","model_type","file_name","mol_fraction","mass_frac","EA_cutoff","ERS_queue","ERS_walltime",\
                "calc_folder", "config_template", "scratch_path","scratch_folds","depot_path","depot_folds","time_step","steps","rule","reactor","num_nodes", "cnf_thresh"]

    keywords = [ _.lower() for _ in keywords ]
    
    list_delimiters = [","]  # values containing any delimiters in this list will be split into lists based on the delimiter
    space_delimiters = ["&"] # values containing any delimiters in this list will be turned into strings with spaces replacing delimiters
    configs = { i:None for i in keywords }    
    with open(args.config,'r') as f:
        for lines in f:
            fields = lines.split()

            # Delete comments
            if "#" in fields:
                del fields[fields.index("#"):]
            # Parse keywords
            l_fields = [ _.lower() for _ in fields ] 
            for i in keywords:
                if i in l_fields:
                    # Parse keyword value pair
                    ind = l_fields.index(i) + 1
                    if len(fields) >= ind + 1:
                        configs[i] = fields[ind]

                        # Handle delimiter parsing of lists
                        for j in space_delimiters:
                            if j in configs[i]:
                                configs[i] = " ".join([ _ for _ in configs[i].split(j) ])
                        for j in list_delimiters:
                            if j in configs[i]:
                                configs[i] = configs[i].split(j)
                                break
                        # Deal with -
                        #if '-' in configs[i]:
                        #    configs[i] = configs[i].replace('-',' ')
                                
                    # Break if keyword is encountered in a non-comment token without an argument
                    else:
                        print("ERROR in python_driver: enountered a keyword ({}) without an argument.".format(i))
                        quit()
       
    # Check that batch is an acceptable system
    if configs["batch"] not in ["pbs","slurm"]:
        print("ERROR in locate_TS: only pbs and slurm are acceptable arguments for the batch variable.")
        quit()
    elif configs["batch"] == "pbs":
        configs["sub_cmd"] = "qsub"
    elif configs["batch"] == "slurm":
        configs["sub_cmd"] = "sbatch"

    # Check that dispersion option is valid
    if configs["dispersion"].lower() == 'none': 
        configs["dispersion"] = None
    elif configs["dispersion"] not in ["D2", "D3", "D3BJ"]:
        print("Gaussian only has D2, D3 and D3BJ Empirical Dispersion, check inputs...")
        quit()

    # Check that solvation option is valid
    if configs["solvation"].lower() == 'none': 
        configs["solvation"] = None
    elif '/' not in configs["solvation"]:
        print("expect A/B format where A refers to model and B refers to solvent")
        quit()

    # Check that relax end is an acceptable system
    if configs["restart_step"] not in ["None","GSM","low-TS","DFT-TS","low-IRC","IRC"]:
        print("ERROR in locate_TS: only None, GSM, low-TS, DFT-TS, low-IRC and IRC are acceptable")
        quit()

    # check settings
    if configs["criterion"] not in ["S","D"]: 
        print("Please specify a correct criterion: 'S' means if IRC nodes match reactant; 'D' means IRC node match either R/P")
        quit()

    # set default value
    # input_type (default:0)
    if configs["input_type"] is None:
        configs["input_type"] = 0
    else:
        configs["input_type"] = int(configs["input_type"])
    
    # apply TCIT
    if configs["apply_tcit"] is None:
        configs["apply_tcit"] = True

    elif configs["apply_tcit"].lower() == 'false':
        configs["apply_tcit"] = False

    else:
        configs["apply_tcit"] = True

    # fixed two end nodes
    if configs["relax_end"] is None:
        configs["relax_end"] = True
    elif configs["relax_end"].lower() == 'false':
        configs["relax_end"] = False
    else:
        configs["relax_end"] = True
    
    # apply joint optimization
    if configs["add-joint"] is None:
        configs["add-joint"] = True
    elif configs["add-joint"].lower() == 'false':
        configs["add-joint"] = False
    else:
        configs["add-joint"] = True

    # set default value for dg_thresh
    if configs["dg_thresh"] is None or configs["dg_thresh"].lower() == 'none':
        configs["dg_thresh"] = None
    else:
        configs["dg_thresh"] = int(configs["dg_thresh"])

    # apply product optimization
    if configs["compute_product"] is None:
        configs["compute_product"] = False
    elif configs["compute_product"].lower() == 'true':
        configs["compute_product"] = True
    else:
        configs["compute_product"] = False

    # remove duplicate TSs or not
    if configs["select_conf"] is None:
        configs["select_conf"] = False
    elif configs["select_conf"].lower() == 'false':
        configs["select_conf"] = False
    else:
        configs["select_conf"] = True

    # IRC at DFT level
    if configs["low-irc"] is None or configs["low-irc"].lower()=="true":                                                                                                                              
        configs["low-irc"]= True
    elif configs["low-irc"].lower()=='false':
        configs["low-irc"]= False

    if configs["dft-irc"] is None:
        configs["dft-irc"] = False

    elif configs["dft-irc"].lower() == 'false':
        configs["dft-irc"] = False

    else:
        configs["dft-irc"] = True
    
    # Nimage (default: 9)
    if configs["nimage"] is None:
        configs["nimage"] = 9

    else:
        configs["nimage"] = int(configs["nimage"])

    # add-tor (default: 0.01)
    if configs["add-tor"] is None:
        configs["add-tor"] = 0.01
    else:
        configs["add-tor"] = float(configs["add-tor"])

    # conv-tor (default: 0.0005)
    if configs["conv-tor"] is None:
        configs["conv-tor"] = 0.0005
    else:
        configs["conv-tor"] = float(configs["conv-tor"])

    if configs["eps"] is None:
        configs["eps"]=0.0
    else:
        configs["eps"]=float(configs["eps"])
    if configs["c_method"] is None or configs["c_method"] == "":                                                                                                                                      
        configs["c_method"] = 'crest'
    return configs

# Function to check and append DFT energies for reactants
def parse_Energy(db_files,E_dict={}):
    with open(db_files,'r') as f:
        for lc,lines in enumerate(f):
            fields = lines.split()
            if lc == 0: continue
            if len(fields) ==0: continue
            if len(fields) >= 4:
                inchi = fields[0][:14]
                if fields[0] not in E_dict.keys():
                    E_dict[inchi] = {}
                    E_dict[inchi]["E_0"]= float(fields[1])
                    E_dict[inchi]["H"]  = float(fields[2])
                    E_dict[inchi]["F"]  = float(fields[3])
                    E_dict[inchi]["SPE"]= float(fields[4])

    return E_dict

# Function that sleeps the script until jobids are no longer in a running or pending state in the queue
def monitor_jobs(jobids):
    
    current_jobs = check_queue()
    while True in [ i in current_jobs for i in jobids ]:
        time.sleep(60)
        current_jobs = check_queue()  
    return

# Returns the pending and running jobids for the user as a list
def check_queue():

    # The first time this function is executed, find the user name and scheduler being used. 
    if not hasattr(check_queue, "user"):

        # Get user name
        check_queue.user = subprocess.check_output("echo ${USER}", shell=True).decode('utf-8').strip("\r\n")

        # Get batch system being used
        squeue_tmp = subprocess.Popen(['which', 'squeue'], stdout=subprocess.PIPE,stderr=subprocess.STDOUT).communicate()[0].decode('utf-8').strip("\r\n")
        qstat_tmp = subprocess.Popen(['which', 'qstat'], stdout=subprocess.PIPE,stderr=subprocess.STDOUT).communicate()[0].decode('utf-8').strip("\r\n")
        check_queue.sched =  None
        if "no squeue in" not in squeue_tmp:
            check_queue.sched = "slurm"
        elif "no qstat in" not in qstat_tmp:
            check_queue.sched = "pbs"
        else:
            print("ERROR in check_queue: neither slurm or pbs schedulers are being used.")
            quit()

    # Get running and pending jobs using the slurm scheduler
    if check_queue.sched == "slurm":

        # redirect a squeue call into output
        output = subprocess.check_output("squeue -l", shell=True).decode('utf-8')

        # Initialize job information dictionary
        jobs = []
        id_ind = None
        for count_i,i in enumerate(output.split('\n')):            
            fields = i.split()
            if len(fields) == 0: continue                
            if id_ind is None and "JOBID" in fields:
                id_ind = fields.index("JOBID")
                if "STATE" not in fields:
                    print("ERROR in check_queue: Could not identify STATE column in squeue -l output.")
                    quit()
                else:
                    state_ind = fields.index("STATE")
                if "USER" not in fields:
                    print("ERROR in check_queue: Could not identify USER column in squeue -l output.")
                    quit()
                else:
                    user_ind = fields.index("USER")
                continue

            # If this job belongs to the user and it is pending or running, then add it to the list of active jobs
            if id_ind is not None and fields[user_ind] == check_queue.user and fields[state_ind] in ["PENDING","RUNNING"]:
                jobs += [fields[id_ind]]

    # Get running and pending jobs using the pbs scheduler
    elif check_queue.sched == "pbs":

        # redirect a qstat call into output
        output = subprocess.check_output("qstat -f", shell=True).decode('utf-8')

        # Initialize job information dictionary
        jobs = []
        job_dict = {}
        current_key = None
        for count_i,i in enumerate(output.split('\n')):
            fields = i.split()
            if len(fields) == 0: continue
            if "Job Id" in i:

                # Check if the previous job belongs to the user and needs to be added to the pending or running list. 
                if current_key is not None:
                    if job_dict[current_key]["State"] in ["R","Q"] and job_dict[current_key]["User"] == check_queue.user:
                        jobs += [current_key]
                current_key = i.split()[2]
                job_dict[current_key] = { "State":"NA", "Name":"NA", "Walltime":"NA", "Queue":"NA", "User":"NA"}
                continue
            if "Job_Name" == fields[0]:
                job_dict[current_key]["Name"] = fields[2]
            if "job_state" == fields[0]:
                job_dict[current_key]["State"] = fields[2]
            if "queue" == fields[0]:
                job_dict[current_key]["Queue"] = fields[2]
            if "Resource_List.walltime" == fields[0]:
                job_dict[current_key]["Walltime"] = fields[2]        
            if "Job_Owner" == fields[0]:
                job_dict[current_key]["User"] = fields[2].split("@")[0]

        # Check if the last job belongs to the user and needs to be added to the pending or running list. 
        if current_key is not None:
            if job_dict[current_key]["State"] in ["R","Q"] and job_dict[current_key]["User"] == check_queue.user:
                jobs += [current_key]

    return jobs

if __name__ == "__main__":
    main(sys.argv[1:])