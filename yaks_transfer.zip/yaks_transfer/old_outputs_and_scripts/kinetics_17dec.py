import sys,os,argparse,fnmatch
import numpy as np
import cantera as ct
import matplotlib.pyplot as plt

# all functions in taffi
sys.path.append('../utilities')
from taffi_functions import *
from utility import return_smi,return_inchikey,parse_smiles

# Author: Michael Woulfe
""" Along with yaml_config.txt (same config file you use for write_yaml.py), runs cantera microkinetic modeling simulation and prints results for future exploration

Notes to self:  copy a yarp config file
                keep it generic and then add different variables for each individual species (if radicals/cations/anions)
                    add a section for cantera simulations

                track useful variables throughout YARP exploration

                submit YARP jobs to cluster, run yaks on sinteractive claimed node
                    - define run_simulation function
                    - define analyze results function?!?
                    - limit print statements

                lists: species to explore, already explored species,
                write all files into a newly created folder (ex: khp_yaks_3_3 [rounds, species])

                difficulties/new ideas: 
                    water catalyzed section (work after normal section works)
                    restart steps: which part of what step?
                    following bad channels/verification schemes.
                    cleaning scheme to delete unnecessary YARP files


        general overview:
            yaks .py (monitor jobs and wait until done for all steps)
                - run yarp on input molecule [written output- YARP folders]
                    - name output_folder _whatever_0_1 (round 0, species 1)
                - write_yaml.py [written output - yaml file]
                - run_kinetic_modeling
                - analyze results [ written output- csv files of , plots?, prioritization]
                Round 2
                - run yarp on top n results (start with 3)
                - 
"""
def main(argv):

    parser = argparse.ArgumentParser(description='Driver script for submitting YARP jobs with Gaussian engine.')

    #optional arguments                                             
    parser.add_argument('-c', dest='config', default='yaml_config.txt',
                        help = 'The program expects a configuration file from which to assign various run conditions. (default: yaml_config.txt in the current working directory).  Conveniently, write_yaml.py and analyze_cantera.py run off same yaml file.')

    print("parsing configuration directory...")
    args=parser.parse_args()
    c = parse_configuration(parser.parse_args())
    run_kinetics(c)

    return


rule = "cnf" # cnf, cum_conc, final_conc
steps = 6000
time_step = 0.1
yaml_path = "/scratch/bell/mwoulfe/yaks/yamls"
yaml_name = "test_0"

input_molecule_smi = "OCC1OC(O)C(C(C1O)O)O" #c["ini_species"]
reactor = "IGCPR"
previous_nodes = []
num_nodes = 3

    

def overarching_script(c):
    

    input_molecule_smi = c["ini_species"]
    output_path= c["output_path"]
    file_name = c["file_name"]
    file_name = "test" # manual testing
    yaml_file = f"{output_path}/{file_name}.yaml"
    print(yaml_file)
    gas = ct.Solution(yaml_file)
    r = ct.IdealGasConstPressureReactor(contents=gas, energy='off', name='isothermal_reactor')
    sim = ct.ReactorNet([r])
    states = ct.SolutionArray(gas, extra=['t'])

    # gives snapshot of system
    print(gas(), f"T0: {gas.T}", f"Species: {len(gas.Y)}", f"Reactions: {len(states.reactions())}")

    species = states.species_names
    rxn_list = states.reactions()

    # Simulation 
    sim.verbose = True
    dt_max = .1  #secs
    t_end = 600 * dt_max
    print('{:10s} {:10s} {:10s} {:14s}'.format(\
        't [s]', 'T [K]', 'P [Pa]', f'Y ({input_molecule_smi})'))
    
    print("loop start")
    # sim loop
    states.append(r.thermo.state, t=sim.time)
    while sim.time <= t_end:
        sim.advance(sim.time + dt_max)
        states.append(r.thermo.state, t=sim.time)

    print("done with loop")
    # trap rule of states. rates along species axis
    spe_cre = np.trapz(states.creation_rates, dx=dt_max, axis=0)
    spe_des = np.trapz(states.destruction_rates, dx=dt_max, axis=0)
    if fnmatch.fnmatch(yaml_file, "*_0.yaml") or fnmatch.fnmatch(yaml_file, "*_pre*"): # ignore first time step if model is beyond first stages of yaml
        spe_net = np.trapz(states.net_production_rates[:], dx=dt_max, axis=0)
    else: spe_net = np.trapz(states.net_production_rates[1:], dx=dt_max, axis=0)    
    rxn_net = np.trapz(states.net_rates_of_progress, dx=dt_max, axis=0)

    # if config to save rates or each simulation, save them to a csv with a different page for each type

    print('analysis begins')
    # net states
    net_states = zip(spe_net,species,range(len(species)))
    net_states = sorted(net_states,reverse=True)[:]

    # get ordered list for net fluxes
    ord_flux = []
    for c, v in enumerate(net_states):
    #     print(c, v[1])
        if input_molecule_smi == v[1]:
            ord_flux.insert(0, net_states[c][2]) # always put starting molecule into ordered list (for plotting)
        else:
            ord_flux.append(net_states[c][2])

    time=10 # add to config
    num =15  # same
    # if c["y_scaling_flux"] == 'log': log = True
    log = True
    plt_spe = []
    for i, val in enumerate(net_states):
        if i <= num:
            plt_spe.append(val[1])
    plt_spe.insert(0,input_molecule_smi)
    print(plt_spe)

    # final_states (mass)
    final_states = zip(states.Y[-1,:],species,range(len(species)))
    final_states = sorted(final_states,reverse=True)[:]

    # get ordered list
    ord_states = []
    for c, v in enumerate(final_states):
        if input_molecule_smi in v:
            ord_states.insert(0, final_states[c][2]) # always put starting molecule into ordered list
        else:
            ord_states.append(final_states[c][2])

    plt_spe = []
    for i, val in enumerate(final_states):
        if i <= num:
            plt_spe.append(val[1])
    plt_spe.insert(0,input_molecule_smi)

    # final_states for moles
    final_states = zip(states.Y[-1,:],species,range(len(species)))
    final_states = sorted(final_states,reverse=True)[:]

    #  zip concentration (moles), species smiles, index
    final_moles = zip(states.X[-1,:],species,range(len(species)))
    final_moles = sorted(final_moles,reverse=True)[:]
    print(final_states[:5],'\n', final_moles[:5])

    # get ordered list
    ord_states = []
    for c, v in enumerate(final_states):
        if input_molecule_smi in v:
            ord_states.insert(0, final_states[c][2]) # always put starting molecule into ordered list
        else:
            ord_states.append(final_states[c][2])

    # will need to save plots to a folder

    plt.figure(figsize=(10,8))
    plt.plot(states.t[:] / 60, states.net_production_rates[:,(ord_flux[:num])], linewidth=2) # without D-glucose
    plt.legend(plt_spe, loc='upper center', bbox_to_anchor=(0.5, -0.15),
            fancybox=True, shadow=True, ncol=4)
    plt.xlabel('time (minutes)')
    # if log = True: plt.yscale('log')
    plt.yscale('log')
    plt.ylabel(f'net production')
    plt.title(f"D-Glucose Net production vs Time")


    
    # mass percent vs Time plot
    print(f"len(species): {len(species)}")
    plt.figure(figsize=(10,8))
    plt.plot(states.t[:] / 60, states.Y[:,(ord_states[:num+2])] * 100, linewidth=2)
    plt.legend(plt_spe, loc='upper center', bbox_to_anchor=(0.5, -0.15),
            fancybox=True, shadow=True, ncol=4)
    plt.xlabel('t (minutes)')
    plt.ylabel(f'Mass Percent (%)')
    plt.title(f"D-Glucose Mass Percent (Top {num} Molecules) vs Time")

    # Numerical Analysis
    threshhold = .01 # mass percent seed for next lvl of exploration
    var = 15

    print(f"\nMass Percents over 1%:")
    for i, val in enumerate(final_states):
        if val[0] > threshhold or val[1] == input_molecule_smi:
            if val[1]== input_molecule_smi:
                print(f" Input Species: {val[1]:<16} Mass Percent: {val[0]:.3f}")
            else:
                print(f" Species: {val[1]:<22} Mass Percent: {val[0]:.3f}")
                
    print(f"\nLargest {var} concentrations:")
    for i in final_moles[:var]: print(F"Species: {i[1]:<18} Concentration: {i[0]:.7f}")

    sum_X = 0
    for i in final_moles:
        sum_X += i[0]
    print(sum_X)
        
    print(f"\nLargest {var} net fluxes:") # spe net calculated ignoring the first step
    top_five = sorted(range(len(spe_net)), key=lambda i: spe_net[i], reverse=True)[:var]
    for i in top_five[:var]:
        print(species[i])

    print(f"\nTop {var} CNF Values :")
    for i in top_five:
        print(f"{spe_net[i]}")

            
    print(f"\nLargest {var} net fluxes:")
    for i in top_five:
        if species[i] == input_molecule_smi:
            print(f" Input Species: {species[i]:<19} Flux: {spe_net[i]:.7f}")
        else:
            print(f" Species: {species[i]:<26} Net Flux: {spe_net[i]:.7f}")
        

  
###########################################
####              FUNCTIONS            ####
###########################################

# function to run kinetic simulation, returns list of previous nodes and, new nodes to explore
def run_kinetics(yaml_path, yaml_name, time_step, steps, rule, reactor, previous_nodes, num_nodes):

    yaml = f"{yaml_path}/{yaml_name}.yaml"
    gas = ct.Solution(yaml)
    if reactor == "IGCPR": r = ct.IdealGasConstPressureReactor(contents=gas, energy='off', name='isothermal_reactor')
    sim = ct.ReactorNet([r])
    states = ct.SolutionArray(gas, extra=['t'])

    # gives snapshot of system
    print(gas(), f"T0: {gas.T}", f"Species: {len(gas.Y)}", f"Reactions: {len(states.reactions())}")

    species = states.species_names
    rxn_list = states.reactions()

    # Simulation 
    sim.verbose = True
    t_end = steps * time_step
    print('{:10s} {:10s} {:10s} {:14s}'.format(\
        't [s]', 'T [K]', 'P [Pa]', f'Y ({input_molecule_smi})'))
    
    print("sim start")
    # sim loop
    states.append(r.thermo.state, t=sim.time)
    while sim.time <= t_end:
        sim.advance(sim.time + time_step)
        states.append(r.thermo.state, t=sim.time)
    print("sim end")

    if rule == 'cnf':
        if fnmatch.fnmatch(yaml, "*_0.yaml") or fnmatch.fnmatch(yaml, "*_pre*"): # ignore first time step if model is beyond first stages of yaml
            spe_net = np.trapz(states.net_production_rates[:], dx=time_step, axis=0)
        else: spe_net = np.trapz(states.net_production_rates[1:], dx=time_step, axis=0)    
        net_states = zip(spe_net,species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]

    elif rule == 'final_conc':
        net_states = zip(states.X[-1,:],species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]
    
    elif rule == 'final_mass':
        net_states = zip(states.Y[-1,:],species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]

    elif rule == 'cum_conc':
        conc_net = np.trapz(states.x[:], dx=time_step, axis=0)
        net_states = zip(conc_net,species,range(len(species)))
        net_states = sorted(net_states,reverse=True)[:]

    # extra analysis
    spe_cre = np.trapz(states.creation_rates, dx=time_step, axis=0)
    spe_des = np.trapz(states.destruction_rates, dx=time_step, axis=0)
    rxn_net = np.trapz(states.net_rates_of_progress, dx=time_step, axis=0)

    # write rates to excel spreadsheet, save in analysis folder
    # make concentration/mass/net creation plots and save them to analysis folder (one folder for each step)

    possible_bimole = []
    new_nodes = []
    for i in net_states:
        if i[1] in previous_nodes: possible_bimole.append(i[1])
        elif i[1] not in previous_nodes:
            new_nodes.append(i[1])
            previous_nodes.append(i[1])
        if len(new_nodes) == num_nodes:
            print(previous_nodes, new_nodes)
            return previous_nodes, new_nodes

# Function for keeping tabs on the validity of the user supplied inputs
def parse_configuration(args):
    
    # Convert inputs to the proper data type
    if os.path.isfile(args.config) is False:
        print("ERROR in python_driver: the configuration file {} does not exist.".format(args.config))
        quit()
    
    # Process configuration file for keywords

    # keywords
    keywords = ["output_path","file_name","ini_species","reactant_dict","q_reactant_dict", "e_dict", "smi2inchi", "scratch_path","scratch_folders","depot_path","depot_folders","batch","sched",\
                "memory","Ea_cutoff", "wall_time","queue", "rads", "rev_rxns", "energy_units", "eos", "elements", "kinetics", "reactions", "temp", "pres", "pres_units", "model_type"]

    keywords = [ _.lower() for _ in keywords ]
    
    list_delimiters = [","]  # values containing any delimiters in this list will be split into lists based on the delimiter
    space_delimiters = ["&"] # values containing any delimiters in this list will be turned into strings with spaces replacing delimiters
    configs = { i:None for i in keywords }    

    with open(args.config,'r') as f:
        for lines in f:
            fields = lines.split()
            
            # Delete comments
            if "#" in fields:
                del fields[fields.index("#"):]

            # Parse keywords
            l_fields = [ _.lower() for _ in fields ] 
            for i in keywords:
                if i in l_fields:
                    # Parse keyword value pair
                    ind = l_fields.index(i) + 1
                    if len(fields) >= ind + 1:
                        configs[i] = fields[ind]

                        # Handle delimiter parsing of lists
                        for j in space_delimiters:
                            if j in configs[i]:
                                configs[i] = " ".join([ _ for _ in configs[i].split(j) ])
                        for j in list_delimiters:
                            if j in configs[i]:
                                configs[i] = configs[i].split(j)
                                break
                        # Deal with -
                        #if '-' in configs[i]:
                        #    configs[i] = configs[i].replace('-',' ')
                                
                    # Break if keyword is encountered in a non-comment token without an argument
                    else:
                        print("ERROR in python_driver: enountered a keyword ({}) without an argument.".format(i))
                        quit()
                        
    # Check that batch is an acceptable system
    if configs["batch"] not in ["pbs","slurm"]:
        print("ERROR in locate_TS: only pbs and slurm are acceptable arguments for the batch variable.")
        quit()
    elif configs["batch"] == "pbs":
        configs["sub_cmd"] = "qsub"
    elif configs["batch"] == "slurm":
        configs["sub_cmd"] = "sbatch"



    return configs

# Function to check and append DFT energies for reactants
def parse_Energy(db_files,E_dict={}):
    with open(db_files,'r') as f:
        for lc,lines in enumerate(f):
            fields = lines.split()
            if lc == 0: continue
            if len(fields) ==0: continue
            if len(fields) >= 4:
                inchi = fields[0][:14]
                if fields[0] not in E_dict.keys():
                    E_dict[inchi] = {}
                    E_dict[inchi]["E_0"]= float(fields[1])
                    E_dict[inchi]["H"]  = float(fields[2])
                    E_dict[inchi]["F"]  = float(fields[3])
                    E_dict[inchi]["SPE"]= float(fields[4])

    return E_dict

if __name__ == "__main__":
    main(sys.argv[1:])